# image_processing_mod

Description. 
The package image_processing_mod is used to:
	Processing
		- Histogram matching 	 
		- Structural similary
		- Relize image
	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_mod

```bash
pip install image_processing_mod
```

## Author
Marcos

## License
[MIT](https://choosealicense.com/licenses/mit/)